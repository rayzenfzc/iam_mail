
import { GoogleGenAI, Type } from "@google/genai";
import { CurriculumDraft, GameSessionData, StudentProfile } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Gemini 3 Flash for low-latency translation (Basic Text Task)
export const translateMessage = async (text: string, targetLanguage: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Translate the following text to ${targetLanguage}. Only output the translated text. Text: "${text}"`,
    });
    // Access response.text property directly
    return response.text || text;
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
};

// Gemini 3 Pro (Deep Think proxy) for Curriculum Logic (Complex Text Task)
export const generateCurriculumDraft = async (
  student: StudentProfile,
  sessionData: GameSessionData[]
): Promise<CurriculumDraft> => {
  const prompt = `
    Act as a Board Certified Behavior Analyst (BCBA).
    Create a weekly curriculum draft for a student with the following profile:
    ${JSON.stringify(student)}

    Recent Session Data:
    ${JSON.stringify(sessionData)}

    Output strictly in JSON format matching this schema:
    {
      "week": number,
      "focusAreas": string[],
      "suggestedActivities": string[],
      "rationale": string
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            week: { type: Type.INTEGER },
            focusAreas: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedActivities: { type: Type.ARRAY, items: { type: Type.STRING } },
            rationale: { type: Type.STRING },
          },
          propertyOrdering: ["week", "focusAreas", "suggestedActivities", "rationale"]
        }
      }
    });

    // Access response.text property directly
    const text = response.text;
    if (text) {
      return JSON.parse(text) as CurriculumDraft;
    }
    throw new Error("Empty response");
  } catch (error) {
    console.error("Curriculum generation error:", error);
     return {
      week: 1,
      focusAreas: ['Error generating plan'],
      suggestedActivities: [],
      rationale: 'AI Service currently unavailable.'
    };
  }
};
