import React, { useState, useEffect, useRef } from 'react';
import { Email, MOCK_EMAILS } from '../types';
import { GoogleGenAI, Modality } from "@google/genai";
import { 
  Search, Mail, Shield, Send, FileText, Video, MoreHorizontal, 
  ChevronRight, MessageSquare, Zap, Calendar, DollarSign, Command,
  Moon, Sun, Menu, X, Bell, Sparkles, SendHorizontal, Plus, ArrowLeft,
  Activity, Layers, Sliders, Volume2, Info, CheckCircle2, ListFilter
} from 'lucide-react';

interface ThreePaneLayoutProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
}

// Helper for Base64 Decoding
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const ThreePaneLayout: React.FC<ThreePaneLayoutProps> = ({ isDarkMode, toggleTheme }) => {
  const [emails] = useState<Email[]>(MOCK_EMAILS);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [tab, setTab] = useState<'focus' | 'other'>('focus');
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isIntelligenceOpen, setIsIntelligenceOpen] = useState(false);
  const [isBriefingLoading, setIsBriefingLoading] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('command-bar')?.focus();
      }
      if (e.key === 'c' && !isComposerOpen) {
        setIsComposerOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isComposerOpen]);

  const handleAudioBriefing = async () => {
    if (isBriefingLoading) return;
    setIsBriefingLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Synthesize a brief audio summary. Tone: Minimalist, clinical excellence.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        const ctx = audioContextRef.current;
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.start();
        source.onended = () => setIsBriefingLoading(false);
      }
    } catch (e) {
      console.error("Audio error", e);
      setIsBriefingLoading(false);
    }
  };

  const filteredEmails = emails.filter(e => e.category === tab);

  return (
    <div className="app-container h-full w-full overflow-hidden transition-all duration-1000 relative font-sans flex flex-col md:rounded-[48px] border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
      
      {/* Global Command Bar - Hides when Sidebar is Open */}
      <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 w-full max-w-lg px-6 z-[250] transition-all duration-500 pointer-events-none ${isSidebarOpen ? 'opacity-0 translate-y-10 scale-90' : 'opacity-100 translate-y-0 scale-100'}`}>
        <div className="pointer-events-auto glass-sexy rounded-full p-1.5 pl-7 flex items-center gap-4 group hover:scale-[1.01] transition-all duration-700">
          <Command size={16} className="text-slate-500 dark:text-slate-400 group-focus-within:text-accent transition-colors" />
          <input 
            id="command-bar" 
            type="text" 
            placeholder="Synthesize command..." 
            className="flex-1 bg-transparent text-[14px] font-light outline-none dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-700 h-9" 
          />
          <button 
            onClick={() => setIsComposerOpen(true)} 
            className="h-9 w-9 bg-slate-900 dark:bg-accent text-white rounded-full flex items-center justify-center hover:scale-105 active:scale-95 shadow-xl transition-all"
          >
            <Plus size={18} />
          </button>
        </div>
      </div>

      {/* Sidebar Drawer */}
      <div className={`fixed inset-0 z-[110] bg-slate-900/40 backdrop-blur-sm transition-opacity duration-700 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsSidebarOpen(false)} />
      <aside className={`fixed inset-y-0 left-0 z-[120] w-[340px] border-r pane-border transition-transform duration-700 bg-white dark:bg-slate-900 flex flex-col shadow-2xl ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-12 flex justify-between items-center">
          <div>
            <div className="font-light text-4xl tracking-tighter leading-none mb-2 dark:text-white">
              <span className="text-slate-400">i.</span><span className="text-slate-700 dark:text-slate-100 font-medium">M</span>
            </div>
            <div className="text-[10px] uppercase tracking-[0.6em] text-slate-400 font-bold">NODE HUB</div>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="p-3 text-slate-400 hover:text-slate-600 transition-colors"><X size={26} /></button>
        </div>

        <nav className="flex-1 px-8 space-y-4">
          {[
            { id: 'inbox', label: 'Inbound', icon: Mail, count: 12 },
            { id: 'sent', label: 'Outbound', icon: Send },
            { id: 'drafts', label: 'Synthesis', icon: FileText },
            { id: 'shield', label: 'Security', icon: Shield, highlight: true },
          ].map((item) => (
            <button key={item.id} className={`w-full flex items-center px-8 py-5 rounded-[24px] transition-all hover:bg-slate-50 dark:hover:bg-slate-800 group ${item.highlight ? 'text-accent' : 'text-slate-600 dark:text-slate-300'}`}>
              <div className="flex items-center gap-6">
                <item.icon size={24} strokeWidth={1.5} className="group-hover:scale-110 transition-transform" />
                <span className="text-[13px] uppercase tracking-[0.2em] font-bold">{item.label}</span>
              </div>
              {item.count && <span className="ml-auto text-[10px] bg-slate-100 dark:bg-slate-800 px-4 py-1.5 rounded-full font-bold">{item.count}</span>}
            </button>
          ))}
        </nav>

        <div className="mt-auto p-10 flex flex-col gap-5">
           <button onClick={toggleTheme} className="w-full flex items-center px-8 py-5 rounded-[24px] hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-500 transition-all border pane-border shadow-sm">
             <div className="min-w-[24px]">{isDarkMode ? <Sun size={24} /> : <Moon size={24} />}</div>
             <span className="text-[13px] uppercase tracking-[0.2em] font-bold ml-6">Luminary</span>
           </button>
        </div>
      </aside>

      {/* Header */}
      <header className="h-28 border-b pane-border flex items-center justify-between px-14 bg-white/80 dark:bg-slate-950/80 backdrop-blur-3xl z-[100]">
        <div className="flex items-center gap-12">
          <button onClick={() => setIsSidebarOpen(true)} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-slate-500 hover:text-slate-900 transition-all border pane-border shadow-sm">
            <Menu size={24} />
          </button>
          <div className="hidden sm:block font-light text-2xl tracking-tighter leading-none dark:text-white uppercase">
            <span className="text-slate-400">i.</span><span className="text-slate-700 dark:text-slate-100 font-medium">M</span>
          </div>
        </div>
        
        <div className="flex items-center gap-8">
          <div className="hidden lg:flex items-center gap-4 bg-slate-50 dark:bg-slate-900 px-6 py-2.5 rounded-full border pane-border">
             <Activity size={14} className="text-green-500 animate-pulse" />
             <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-slate-500">SYNC: 14MS</span>
          </div>
          <button className="p-3 text-slate-400"><Bell size={26} /></button>
          <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center text-slate-600 dark:text-slate-300 font-bold border pane-border shadow-lg">AM</div>
        </div>
      </header>

      {/* Main Framework Area */}
      <div className="flex flex-1 overflow-hidden relative">
        <section className={`flex flex-col border-r pane-border bg-white dark:bg-slate-950 transition-all duration-700 ${selectedEmail ? 'hidden lg:flex lg:w-[480px]' : 'flex-1'}`}>
          <div className="p-10 border-b pane-border flex justify-between items-center">
            <div className="flex gap-10">
              <button onClick={() => setTab('focus')} className={`text-[12px] uppercase tracking-[0.3em] font-bold pb-4 border-b-2 transition-all ${tab === 'focus' ? 'border-accent text-slate-800 dark:text-white' : 'border-transparent text-slate-500'}`}>Primary</button>
              <button onClick={() => setTab('other')} className={`text-[12px] uppercase tracking-[0.3em] font-bold pb-4 border-b-2 transition-all ${tab === 'other' ? 'border-accent text-slate-800 dark:text-white' : 'border-transparent text-slate-500'}`}>Other</button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto hide-scrollbar divide-y divide-slate-50 dark:divide-slate-900/30">
            {filteredEmails.map((email) => (
              <div key={email.id} onClick={() => setSelectedEmail(email)} className={`p-10 cursor-pointer transition-all hover:bg-slate-50 dark:hover:bg-slate-900/40 relative group ${selectedEmail?.id === email.id ? 'bg-slate-50 dark:bg-slate-900/60' : ''}`}>
                <div className={`absolute left-0 top-0 bottom-0 w-1 animate-neural ${email.category === 'focus' ? 'bg-accent' : 'bg-slate-200 dark:bg-slate-800'}`}></div>
                <div className="flex justify-between items-start mb-4">
                  <span className={`text-[12px] uppercase tracking-[0.2em] font-bold ${!email.isRead ? 'text-slate-800 dark:text-slate-100' : 'text-slate-500'}`}>{email.sender}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">{email.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </div>
                <h4 className={`text-[17px] mb-3 line-clamp-1 ${!email.isRead ? 'font-bold text-slate-800 dark:text-white' : 'font-light text-slate-600 dark:text-slate-400'}`}>{email.subject}</h4>
                <p className="text-[14px] text-slate-500 dark:text-slate-400 line-clamp-2 font-light leading-relaxed mb-4">{email.snippet}</p>
              </div>
            ))}
          </div>
        </section>

        <main className={`flex-1 flex flex-col bg-slate-50/5 dark:bg-slate-950 relative overflow-hidden transition-all duration-700 ${selectedEmail ? 'flex' : 'hidden lg:flex'}`}>
          {selectedEmail ? (
            <div className="flex-1 flex flex-col h-full overflow-hidden animate-in fade-in zoom-in-95 duration-700 relative">
              <div className="lg:hidden p-8 border-b pane-border">
                <button onClick={() => setSelectedEmail(null)} className="flex items-center gap-4 text-slate-500 font-bold uppercase text-[12px] tracking-[0.2em]"><ArrowLeft size={20} /> Back</button>
              </div>

              <div className="bg-slate-900/95 dark:bg-slate-900/90 backdrop-blur-2xl text-white px-12 py-5 flex items-center justify-between z-10 shadow-xl">
                <div className="flex items-center gap-10 text-accent">
                  <Sparkles size={20} className="animate-pulse" />
                  <span className="text-[12px] uppercase tracking-[0.5em] font-bold italic">Node Synthesis</span>
                </div>
                <button onClick={() => setIsIntelligenceOpen(!isIntelligenceOpen)} className={`p-2.5 rounded-xl transition-all ${isIntelligenceOpen ? 'bg-accent' : 'hover:bg-white/10 text-slate-400'}`}><Info size={22} /></button>
              </div>

              <div className="flex-1 flex overflow-hidden">
                <div className="flex-1 overflow-y-auto hide-scrollbar scroll-smooth">
                  <div className="p-16 lg:p-32 max-w-5xl mx-auto w-full">
                    <div className="flex flex-col lg:flex-row justify-between items-start gap-16 mb-24">
                      <h2 className="text-5xl lg:text-8xl thin-title text-slate-800 dark:text-slate-100 uppercase leading-[1] tracking-tight">{selectedEmail.subject}</h2>
                      <button className="px-14 py-6 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[24px] text-[12px] uppercase tracking-[0.5em] font-bold shadow-2xl">REPLY</button>
                    </div>
                    
                    <div className="flex items-center gap-8 mb-20">
                      <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-[24px] flex items-center justify-center font-bold text-slate-400 text-2xl uppercase border pane-border">{selectedEmail.sender.charAt(0)}</div>
                      <div>
                        <div className="text-lg font-bold text-slate-700 dark:text-white uppercase tracking-[0.1em]">{selectedEmail.sender}</div>
                        <div className="text-[13px] text-slate-400 font-medium italic mt-2 tracking-widest">{selectedEmail.senderEmail}</div>
                      </div>
                    </div>

                    <div className="text-2xl font-light text-slate-600 dark:text-slate-300 leading-[1.65] whitespace-pre-wrap max-w-4xl tracking-tight mb-32">
                      {selectedEmail.body}
                    </div>
                  </div>
                </div>

                <div className={`border-l pane-border bg-white dark:bg-slate-900/40 backdrop-blur-3xl transition-all duration-700 ${isIntelligenceOpen ? 'w-[400px]' : 'w-0 opacity-0 overflow-hidden'}`}>
                  <div className="p-12 space-y-16 min-w-[400px]">
                    <div className="space-y-8">
                      <h5 className="text-[11px] uppercase tracking-[0.4em] text-accent font-bold">Intelligence Extract</h5>
                      <div className="p-8 bg-slate-50 dark:bg-slate-800/50 rounded-[28px] border pane-border">
                         <p className="text-sm font-light text-slate-500 mb-4 leading-relaxed uppercase italic tracking-wide">Analysis complete. Priority 1.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-16 lg:p-32 text-center bg-white dark:bg-slate-950 transition-all">
              <div className="mb-20 relative">
                <div className={`absolute inset-0 bg-accent/20 blur-[120px] rounded-full scale-[4] transition-all duration-1000 ${isBriefingLoading ? 'animate-pulse' : 'opacity-20'}`}></div>
                <div className="w-40 h-40 bg-slate-50 dark:bg-slate-900 rounded-[48px] flex items-center justify-center border pane-border relative z-10 shadow-2xl">
                  {isBriefingLoading ? (
                    <div className="flex items-center gap-1.5 h-10">
                       {[1, 2, 3, 2, 1, 4, 2].map((h, i) => <div key={i} className="w-1 bg-accent rounded-full animate-bounce" style={{height: `${h*8}px`, animationDelay: `${i*0.1}s`}}></div>)}
                    </div>
                  ) : (
                    <Activity size={64} className="text-slate-300 dark:text-slate-700" strokeWidth={1} />
                  )}
                </div>
              </div>
              <h3 className="text-7xl lg:text-9xl thin-title text-slate-800 dark:text-white uppercase mb-8 tracking-tighter">Iamthemail</h3>
              <p className="max-w-lg text-slate-400 font-light text-xl leading-relaxed mb-20 tracking-wide">Cognitive synthesis optimized.</p>
              <button onClick={handleAudioBriefing} disabled={isBriefingLoading} className="flex items-center gap-5 px-14 py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[28px] text-[13px] uppercase tracking-[0.5em] font-bold shadow-3xl hover:scale-105 transition-all">
                <Volume2 size={22} /> {isBriefingLoading ? 'Processing...' : 'Listen Briefing'}
              </button>
            </div>
          )}
        </main>
      </div>

      <style>{`
        .glass-sexy {
          background: rgba(255, 255, 255, 0.7);
          backdrop-filter: blur(40px);
          -webkit-backdrop-filter: blur(40px);
          border: 1px solid rgba(15, 23, 42, 0.45);
          box-shadow: 0 20px 50px -10px rgba(0,0,0,0.15);
        }
        .dark .glass-sexy {
          background: rgba(15, 23, 42, 0.7);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 20px 50px -10px rgba(0,0,0,0.5);
        }
      `}</style>

      {/* Composer Overlay */}
      {isComposerOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-900/70 backdrop-blur-2xl p-12 lg:p-24 animate-in fade-in duration-500">
          <div className="w-full max-w-6xl bg-white dark:bg-slate-900 shadow-[0_60px_150px_-30px_rgba(0,0,0,0.5)] rounded-[64px] overflow-hidden flex flex-col h-[85vh] transition-all border pane-border relative">
            <div className="p-12 border-b pane-border flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/20">
              <div className="flex items-center gap-6">
                <div className="p-4 bg-accent/15 rounded-2xl"><Sparkles size={24} className="text-accent animate-pulse" /></div>
                <span className="text-[14px] uppercase tracking-[0.6em] font-bold text-slate-400 italic">Neural Ghostwriter</span>
              </div>
              <button onClick={() => setIsComposerOpen(false)} className="text-[12px] uppercase tracking-[0.3em] font-bold bg-slate-200 dark:bg-slate-800 px-10 py-4 rounded-[24px]">DISCARD</button>
            </div>
            <div className="p-16 lg:p-28 flex-1 space-y-16 overflow-y-auto hide-scrollbar">
              <input type="text" placeholder="NODE" className="w-full bg-transparent text-4xl font-light outline-none dark:text-white border-b pane-border pb-6" />
              <textarea className="w-full h-full min-h-[400px] resize-none outline-none font-light text-4xl leading-[1.6] bg-transparent text-slate-600 dark:text-slate-300" placeholder="Commence neural intent..."></textarea>
            </div>
            <div className="p-16 border-t pane-border bg-slate-50/50 dark:bg-slate-800/10 flex justify-end">
              <button className="bg-slate-900 dark:bg-accent text-white px-24 py-6 rounded-[28px] text-[14px] uppercase tracking-[0.6em] font-bold shadow-2xl">TRANSMIT</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ThreePaneLayout;