import React from 'react';
import { ViewState } from '../types';

interface LandingProps {
  onNavigate: (view: ViewState) => void;
}

const Landing: React.FC<LandingProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-white flex flex-col overflow-x-hidden">
      <nav className="p-8 md:p-12 flex justify-between items-center z-10">
        <div className="font-light text-2xl tracking-tighter leading-none">
          <span className="text-slate-400">i.</span><span className="text-slate-900 font-medium">M</span>
        </div>
        <div className="flex gap-8 items-center">
          <span className="text-[10px] uppercase tracking-[0.3em] text-slate-500 font-bold hidden sm:block italic">www.iammail.app</span>
          <button 
            onClick={() => onNavigate(ViewState.LOGIN)}
            className="text-[10px] uppercase tracking-[0.2em] font-bold border-b-2 border-slate-200 pb-1 hover:border-primary transition-all text-slate-900"
          >
            Enter Ecosystem
          </button>
        </div>
      </nav>

      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center">
        <div className="mb-6 flex items-center gap-4 opacity-60">
           <div className="h-px w-12 bg-slate-900"></div>
           <span className="text-[10px] uppercase tracking-[0.5em] font-bold text-slate-900">The New Standard in Communication</span>
           <div className="h-px w-12 bg-slate-900"></div>
        </div>
        
        <h1 className="thin-title text-7xl md:text-[12rem] uppercase leading-[0.8] text-slate-900 mb-12">
          <span className="opacity-40">i AM</span><br/>
          <span className="font-light">MAIL</span>
        </h1>
        
        <p className="max-w-xl text-slate-700 font-light text-sm md:text-lg leading-relaxed tracking-wide mb-16 px-4">
          A minimalist AI ecosystem that synthesizes communication into intelligence. Designed for focus. Built for precision.
        </p>

        <div className="flex flex-col md:flex-row gap-8 items-center">
           <button 
             onClick={() => onNavigate(ViewState.LOGIN)}
             className="bg-slate-900 text-white px-16 py-5 uppercase text-[11px] tracking-[0.4em] font-bold hover:bg-primary transition-all duration-500 shadow-2xl shadow-purple-100"
           >
             Initialize Inbox
           </button>
           <button className="text-slate-500 uppercase text-[9px] tracking-[0.3em] font-bold hover:text-slate-900 transition-colors">
             The Synthesis Method
           </button>
        </div>
      </main>

      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vh] border border-slate-100 pointer-events-none -z-0"></div>
      
      <footer className="p-12 text-center opacity-40">
         <p className="text-[9px] uppercase tracking-[0.8em] font-bold italic text-slate-900">Validated Node Infrastructure • www.iammail.app</p>
      </footer>
    </div>
  );
};

export default Landing;