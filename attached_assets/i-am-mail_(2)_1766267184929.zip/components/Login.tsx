import React, { useState } from 'react';
import { ViewState } from '../types';

interface LoginProps {
  onLogin: () => void;
  onBack: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onBack }) => {
  const [email, setEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      onLogin();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row">
      <div className="hidden md:flex flex-1 bg-slate-900 items-center justify-center p-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
           <div className="absolute top-1/4 left-1/4 w-96 h-96 border border-white/20 rounded-full animate-pulse"></div>
        </div>
        <div className="z-10 text-center">
           <h2 className="thin-title text-8xl uppercase text-white leading-none mb-6">i AM</h2>
           <p className="text-white/60 uppercase tracking-[0.5em] font-bold text-[10px]">Ecosystem Identity</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col p-8 md:p-24 justify-center bg-white relative">
        <button 
          onClick={onBack}
          className="absolute top-12 left-8 md:left-24 text-slate-400 hover:text-slate-900 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="square" strokeWidth={1} d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
        </button>

        <div className="max-w-md w-full mx-auto">
          <div className="mb-16">
             <div className="font-light text-3xl tracking-tighter leading-none mb-4">
               <span className="text-slate-400">i.</span><span className="text-slate-900 font-medium">M</span>
             </div>
             <h1 className="text-2xl font-light text-slate-900 mb-2">Secure Inbox Access</h1>
             <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Entry to www.iammail.app</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-10">
            <div className="group">
              <label className="block text-[9px] uppercase tracking-[0.3em] text-slate-500 mb-3 group-focus-within:text-primary transition-colors font-bold">Identifier</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter authorized email..."
                className="w-full border-b-2 border-slate-200 py-4 outline-none font-light text-slate-900 focus:border-primary transition-all bg-transparent placeholder:text-slate-300"
              />
            </div>
            
            <div className="group">
              <label className="block text-[9px] uppercase tracking-[0.3em] text-slate-500 mb-3 group-focus-within:text-primary transition-colors font-bold">Verification Key</label>
              <input 
                type="password" 
                required
                placeholder="••••••••"
                className="w-full border-b-2 border-slate-200 py-4 outline-none font-light text-slate-900 focus:border-primary transition-all bg-transparent placeholder:text-slate-300"
              />
            </div>

            <button 
              type="submit"
              disabled={isProcessing}
              className={`w-full bg-slate-900 text-white py-5 uppercase text-[10px] tracking-[0.4em] font-bold hover:bg-primary transition-all flex items-center justify-center gap-4 shadow-lg ${isProcessing ? 'opacity-50 cursor-wait' : ''}`}
            >
              {isProcessing ? 'Validating Node...' : 'Authenticate'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;