import React from 'react';
import { Email } from '../types';

interface InboxProps {
  emails: Email[];
}

const Inbox: React.FC<InboxProps> = ({ emails }) => {
  return (
    <div className="p-6 pb-24 md:p-16 h-full flex flex-col overflow-hidden">
      <div className="mb-12 flex justify-between items-end">
        <div>
          <h1 className="text-4xl md:text-5xl thin-title text-slate-900 uppercase leading-none">
            <span className="opacity-50">Communications</span><br/>
            Inbox
          </h1>
          <p className="text-[10px] tracking-[0.3em] uppercase mt-4 text-slate-500 font-bold">Verified Nodes • i AM MAIL</p>
        </div>
        <div className="hidden md:flex gap-8">
           <div className="text-right">
              <div className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-bold">Status</div>
              <div className="text-xs font-light text-slate-900">Clear</div>
           </div>
           <div className="text-right">
              <div className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-bold">Network</div>
              <div className="text-xs font-light text-slate-900">Encrypted</div>
           </div>
        </div>
      </div>

      <div className="flex-1 bg-white border border-slate-200 overflow-y-auto shadow-sm">
        <table className="w-full text-left">
          <thead className="sticky top-0 bg-white border-b border-slate-200 z-10">
            <tr>
              <th className="px-6 py-4 text-[9px] uppercase tracking-[0.3em] text-slate-500 font-bold">Sender</th>
              <th className="px-6 py-4 text-[9px] uppercase tracking-[0.3em] text-slate-500 font-bold">Subject</th>
              <th className="px-6 py-4 text-[9px] uppercase tracking-[0.3em] text-slate-500 font-bold text-right">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {emails.map((email) => (
              <tr key={email.id} className="group hover:bg-slate-50 transition-all cursor-pointer">
                <td className="px-6 py-8">
                  <div className="flex items-center gap-4">
                    {!email.isRead && <div className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(139,92,246,0.4)]"></div>}
                    <div className={`text-sm ${!email.isRead ? 'text-slate-900 font-medium' : 'text-slate-600 font-light'}`}>{email.sender}</div>
                  </div>
                </td>
                <td className="px-6 py-8">
                  <div className={`text-sm ${!email.isRead ? 'text-slate-900 font-medium' : 'text-slate-600 font-light'}`}>{email.subject}</div>
                  <div className="text-[10px] text-slate-500 font-light mt-1 truncate max-w-xs md:max-w-md">{email.snippet}</div>
                </td>
                <td className="px-6 py-8 text-right">
                  <div className="text-[10px] text-slate-400 uppercase tracking-tighter group-hover:text-slate-700 transition-colors font-medium">
                    {email.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Inbox;