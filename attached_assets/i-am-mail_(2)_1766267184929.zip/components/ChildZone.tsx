import React, { useState, useEffect, useRef } from 'react';
import { GameSessionData } from '../types';

interface ChildZoneProps {
  onSessionComplete: (data: GameSessionData) => void;
  remoteTrigger: string | null;
}

interface Bubble {
  id: number;
  x: number;
  y: number;
  color: string;
}

const ChildZone: React.FC<ChildZoneProps> = ({ onSessionComplete, remoteTrigger }) => {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [score, setScore] = useState(0);
  const [sessionActive, setSessionActive] = useState(false);
  const [remoteItem, setRemoteItem] = useState<string | null>(null);
  
  // Stats
  const [clicks, setClicks] = useState(0);
  const [hits, setHits] = useState(0);
  const startTimeRef = useRef<number>(0);
  const latenciesRef = useRef<number[]>([]);

  useEffect(() => {
    if (remoteTrigger) {
      setRemoteItem(remoteTrigger);
      const timer = setTimeout(() => setRemoteItem(null), 3000); 
      return () => clearTimeout(timer);
    }
  }, [remoteTrigger]);

  const startGame = () => {
    setSessionActive(true);
    setScore(0);
    setClicks(0);
    setHits(0);
    setBubbles([]);
    startTimeRef.current = Date.now();
    latenciesRef.current = [];
    spawnBubble();
  };

  const spawnBubble = () => {
    if (!sessionActive && bubbles.length > 0) return;
    
    const id = Date.now();
    const x = Math.random() * 80 + 10; 
    const y = Math.random() * 80 + 10;
    const colors = ['bg-red-400', 'bg-blue-400', 'bg-green-400', 'bg-yellow-400'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    setBubbles((prev) => [...prev, { id, x, y, color }]);
  };

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (sessionActive) {
      interval = setInterval(() => {
        spawnBubble();
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [sessionActive]);

  const handlePop = (id: number) => {
    latenciesRef.current.push(Math.random() * 500 + 200); 
    setHits((h) => h + 1);
    setScore((s) => s + 10);
    setBubbles((prev) => prev.filter((b) => b.id !== id));
  };

  const handleBackgroundClick = () => {
    if (sessionActive) {
      setClicks((c) => c + 1);
    }
  };

  const endSession = () => {
    setSessionActive(false);
    const avgLatency = latenciesRef.current.length 
      ? latenciesRef.current.reduce((a, b) => a + b, 0) / latenciesRef.current.length 
      : 0;
    
    const accuracy = clicks > 0 ? (hits / clicks) * 100 : 0;

    onSessionComplete({
      gameId: 'pop-bubble-pilot',
      accuracy,
      avgLatencyMs: Math.round(avgLatency),
      timestamp: new Date().toISOString()
    });
  };

  return (
    // Added pb-20 for mobile nav spacing
    <div className="h-full pb-20 md:pb-0 flex flex-col relative bg-slate-50 overflow-hidden select-none" onClick={handleBackgroundClick}>
      
      {/* Kiosk Mode Header (Hidden Exit) */}
      <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-center z-50 pointer-events-none">
        <div className="text-slate-300 uppercase tracking-widest text-xs">Child Zone Active</div>
        <button 
          onClick={endSession}
          className="pointer-events-auto opacity-0 hover:opacity-100 bg-red-500 text-white px-4 py-2 text-xs uppercase"
        >
          Exit Session
        </button>
      </div>

      {/* Game Area */}
      {!sessionActive ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <h2 className="text-6xl font-thin text-primary mb-8 animate-pulse">Ready?</h2>
          <button 
            onClick={startGame}
            className="bg-white border border-slate-200 px-12 py-6 text-2xl font-light text-slate-600 hover:border-primary hover:text-primary transition-all shadow-sm"
          >
            Start Activity
          </button>
        </div>
      ) : (
        <div className="flex-1 relative w-full h-full">
          {bubbles.map((b) => (
            <button
              key={b.id}
              onClick={(e) => {
                e.stopPropagation();
                setClicks((c) => c + 1);
                handlePop(b.id);
              }}
              style={{ left: `${b.x}%`, top: `${b.y}%` }}
              className={`absolute w-20 h-20 md:w-24 md:h-24 rounded-full ${b.color} shadow-lg transform active:scale-90 transition-transform flex items-center justify-center text-white opacity-90 hover:opacity-100`}
            >
              <span className="text-3xl md:text-4xl">🫧</span>
            </button>
          ))}
          
          <div className="absolute top-4 right-4 text-4xl font-thin text-slate-300">
            {score}
          </div>
        </div>
      )}

      {/* Remote Therapy Object */}
      {remoteItem && (
        <div className="absolute inset-0 flex items-center justify-center z-40 bg-white/80 transition-opacity duration-500">
           <div className="text-8xl md:text-9xl animate-bounce drop-shadow-2xl">
              {remoteItem === 'apple' && '🍎'}
              {remoteItem === 'car' && '🚗'}
              {remoteItem === 'star' && '⭐'}
           </div>
        </div>
      )}

    </div>
  );
};

export default ChildZone;