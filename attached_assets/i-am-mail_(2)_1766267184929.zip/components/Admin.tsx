import React from 'react';
import { StudentProfile } from '../types';

interface AdminProps {
  students: StudentProfile[];
}

const Admin: React.FC<AdminProps> = ({ students }) => {
  return (
    <div className="p-6 pb-24 md:p-16 h-full overflow-y-auto">
       <div className="mb-16">
        <h1 className="text-4xl md:text-5xl thin-title text-slate-900 uppercase leading-none">
          System<br/>
          <span className="opacity-40">Management</span>
        </h1>
        <p className="text-[10px] tracking-[0.3em] uppercase mt-4 text-slate-400 font-light">Admin Console • i AM AURA</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24">
        <div className="col-span-1">
          <div className="flex justify-between items-baseline mb-10 border-b border-slate-50 pb-4">
            <h3 className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-light">Service Records</h3>
            <span className="text-[9px] text-slate-300">Currency: AED</span>
          </div>
          
          <div className="space-y-4">
             {students.map(s => (
               <div key={s.id} className="bg-white p-8 border border-slate-100 hover:border-primary/20 transition-all group flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                 <div>
                    <div className="text-lg font-light text-slate-800">{s.name}</div>
                    <div className="text-[10px] uppercase tracking-widest text-slate-400 mt-1">Fee: {s.ratePerHour} / hr</div>
                 </div>
                 <button className="w-full md:w-auto text-[9px] uppercase tracking-[0.2em] font-medium bg-slate-900 text-white px-6 py-3 hover:bg-primary transition-colors">
                   Generate Receipt
                 </button>
               </div>
             ))}
          </div>
        </div>

        <div className="col-span-1">
          <div className="mb-10 border-b border-slate-50 pb-4">
             <h3 className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-light">Onboarding Pipeline</h3>
          </div>
           <div className="bg-slate-50 border border-slate-100 p-12 flex flex-col items-center justify-center min-h-[300px] text-center">
              <div className="w-16 h-16 border border-slate-200 flex items-center justify-center mb-6 text-slate-200">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="square" strokeWidth={1} d="M12 4v16m8-8H4"/></svg>
              </div>
              <h4 className="font-light text-slate-400 text-sm uppercase tracking-widest mb-4">No active requests</h4>
              <button className="text-primary text-[10px] uppercase tracking-[0.2em] font-medium border-b border-primary/20 pb-1 hover:border-primary transition-all">Share Onboarding URL</button>
           </div>
           
           <div className="mt-12 pt-8 border-t border-slate-50 text-center">
              <p className="text-[10px] text-slate-300 uppercase tracking-[0.5em] font-light">www.iamaura.app</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;