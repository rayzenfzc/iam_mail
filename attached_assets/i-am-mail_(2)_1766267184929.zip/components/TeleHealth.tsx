import React, { useState, useEffect, useRef } from 'react';

interface TeleHealthProps {
  onTriggerRemote: (item: string) => void;
}

const TeleHealth: React.FC<TeleHealthProps> = ({ onTriggerRemote }) => {
  const [isCallActive, setIsCallActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const triggerItems = [
    { id: 'apple', label: 'Apple', icon: '🍎' },
    { id: 'car', label: 'Car', icon: '🚗' },
    { id: 'star', label: 'Reward', icon: '⭐' },
  ];

  useEffect(() => {
    if (isCallActive) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: false })
        .then((currentStream) => {
          setStream(currentStream);
          if (videoRef.current) {
            videoRef.current.srcObject = currentStream;
          }
        })
        .catch((err) => {
          console.error("Error accessing camera:", err);
          alert("Could not access camera. Please allow permissions.");
          setIsCallActive(false);
        });
    } else {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
    }
  }, [isCallActive]);

  return (
    <div className="p-6 pb-24 md:p-16 h-full flex flex-col gap-10 overflow-y-auto">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl md:text-5xl thin-title text-slate-900 uppercase leading-none">
            <span className="opacity-40">Skill Guidance</span><br/>
            Zone
          </h1>
          <p className="text-[10px] tracking-[0.3em] uppercase mt-4 text-slate-400 font-light italic">Validated Session via www.iamaura.app</p>
        </div>
        <div className="flex gap-4">
           <button 
             onClick={() => setIsCallActive(!isCallActive)}
             className={`px-8 py-3 uppercase text-[10px] tracking-[0.2em] border transition-all ${isCallActive ? 'bg-white border-red-200 text-red-500 hover:bg-red-50' : 'bg-slate-900 border-slate-900 text-white hover:bg-primary hover:border-primary'}`}
           >
             {isCallActive ? 'End Session' : 'Talk to Aura'}
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-12 flex-1">
        <div className="col-span-1 md:col-span-2 bg-slate-50 relative flex items-center justify-center overflow-hidden border border-slate-100 aspect-video md:aspect-auto min-h-[400px]">
           {isCallActive ? (
             <>
               <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  muted 
                  className="w-full h-full object-cover transform scale-x-[-1]" 
               />
               <div className="absolute top-6 left-6 flex items-center gap-3">
                 <div className="bg-red-500 w-2 h-2 rounded-full animate-pulse"></div>
                 <span className="text-white text-[9px] uppercase tracking-[0.3em] bg-black/40 px-3 py-1.5 backdrop-blur-sm">Live Connection</span>
               </div>
             </>
           ) : (
             <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 border border-slate-200 flex items-center justify-center text-slate-200">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="square" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                </div>
                <div className="text-slate-300 font-light text-xs uppercase tracking-[0.2em]">Ready for encrypted connection</div>
             </div>
           )}
           
           {isCallActive && (
             <div className="absolute bottom-6 right-6 w-40 h-24 bg-white border border-slate-200 shadow-2xl overflow-hidden p-1">
                <div className="w-full h-full bg-slate-100 flex items-center justify-center">
                   <span className="text-[8px] uppercase tracking-widest text-slate-400">Guide View</span>
                </div>
             </div>
           )}
        </div>

        <div className="col-span-1 flex flex-col gap-8">
           <div className="bg-white border border-slate-100 p-8 flex-1 aura-glow transition-all">
              <h3 className="text-[9px] uppercase tracking-[0.3em] text-slate-400 mb-8 font-light">Interactive Control</h3>
              <div className="grid grid-cols-2 gap-6">
                {triggerItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onTriggerRemote(item.id)}
                    className="aspect-square bg-white border border-slate-50 hover:border-primary/20 hover:shadow-xl transition-all flex flex-col items-center justify-center gap-3 group"
                  >
                    <span className="text-4xl filter grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-500">{item.icon}</span>
                    <span className="text-[9px] uppercase tracking-[0.2em] text-slate-400 group-hover:text-primary">{item.label}</span>
                  </button>
                ))}
              </div>
           </div>

           <div className="bg-slate-50 border border-slate-100 p-8 h-48">
              <h3 className="text-[9px] uppercase tracking-[0.3em] text-slate-400 mb-4 font-light">Skill Observations</h3>
              <textarea className="w-full h-full bg-transparent resize-none outline-none text-slate-600 font-light text-sm p-0 placeholder:text-slate-300" placeholder="Input behavioral markers..."></textarea>
           </div>
        </div>
      </div>
    </div>
  );
};

export default TeleHealth;