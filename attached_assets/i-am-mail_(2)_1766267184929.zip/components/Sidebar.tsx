import React from 'react';
import { ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { view: ViewState.INTELLIGENCE, label: 'Intelligence', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { view: ViewState.INBOX, label: 'Inbox', icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z' },
    { view: ViewState.COMPOSE, label: 'Compose', icon: 'M12 4v16m8-8H4' },
    { view: ViewState.SYSTEM, label: 'System', icon: 'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4' },
  ];

  return (
    <>
      {/* Mobile Nav */}
      <div className="fixed bottom-0 left-0 w-full h-20 bg-white border-t border-slate-200 flex items-center justify-around z-50 md:hidden pb-safe">
        {navItems.map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={`p-4 rounded-full transition-all duration-300 ${
              currentView === item.view ? 'text-primary bg-purple-50' : 'text-slate-500'
            }`}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="square" strokeLinejoin="miter" strokeWidth={1.5} d={item.icon} />
            </svg>
          </button>
        ))}
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-24 bg-white border-r border-slate-200 flex-col items-center py-8 h-screen sticky top-0">
        <div className="mb-12 flex flex-col items-center">
          <div className="font-light text-2xl tracking-tighter leading-none">
            <span className="text-slate-400">i.</span><span className="text-slate-900 font-medium">M</span>
          </div>
          <div className="text-[7px] uppercase tracking-[0.2em] text-slate-500 mt-2 font-medium italic">MAIL</div>
        </div>
        
        <div className="flex-1 flex flex-col gap-10">
          {navItems.map((item) => (
            <button
              key={item.view}
              onClick={() => onNavigate(item.view)}
              className={`group flex flex-col items-center gap-1 transition-all duration-300 ${
                currentView === item.view ? 'text-primary' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <div className={`p-3 border transition-all ${currentView === item.view ? 'bg-slate-50 border-slate-200' : 'bg-transparent border-transparent'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="square" strokeLinejoin="miter" strokeWidth={1.2} d={item.icon} />
                </svg>
              </div>
              <span className="text-[8px] uppercase tracking-widest font-medium opacity-0 group-hover:opacity-100 transition-opacity">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-auto flex flex-col items-center gap-4">
           <div className="w-8 h-px bg-slate-200"></div>
           <div className="[writing-mode:vertical-lr] rotate-180 text-[8px] uppercase tracking-[0.3em] text-slate-400 font-medium">
             www.iammail.app
           </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;