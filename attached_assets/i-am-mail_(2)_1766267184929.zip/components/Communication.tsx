import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { translateMessage } from '../services/geminiService';

const Communication: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'parent', text: 'Hello, how did the session go?', originalText: 'नमस्ते, सत्र कैसा रहा?', timestamp: new Date(Date.now() - 3600000), isTranslated: true }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const parentLanguage = 'Hindi';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSend = async () => {
    if (!inputText.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'guide',
      text: inputText,
      timestamp: new Date(),
      isTranslated: false
    };

    setMessages(prev => [...prev, newMessage]);
    setInputText('');
    setIsTranslating(true);

    setTimeout(async () => {
      const parentReplyNative = "I am happy to hear that. He practiced at home.";
      const translatedReply = await translateMessage(parentReplyNative, "English");
      
      const reply: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'parent',
        text: translatedReply,
        originalText: "मुझे यह सुनकर खुशी हुई। उन्होंने घर पर अभ्यास किया।",
        timestamp: new Date(),
        isTranslated: true
      };
      setMessages(prev => [...prev, reply]);
      setIsTranslating(false);
    }, 2000);
  };

  return (
    <div className="h-full flex flex-col p-6 md:p-16 pb-24 md:pb-16">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl thin-title text-slate-900 uppercase leading-none">
          Communication<br/>
          <span className="opacity-40">Hub</span>
        </h1>
        <div className="flex items-center gap-3 mt-4">
           <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
           <p className="text-[10px] tracking-[0.2em] uppercase text-slate-400 font-light">Node: English ↔ {parentLanguage} (AI Active)</p>
        </div>
      </div>

      <div className="flex-1 bg-white border border-slate-100 flex flex-col h-full overflow-hidden shadow-sm">
        <div className="flex-1 p-6 md:p-10 overflow-y-auto flex flex-col gap-8">
          {messages.map((msg) => (
            <div key={msg.id} className={`max-w-[85%] md:max-w-[60%] ${msg.sender === 'guide' ? 'self-end' : 'self-start'}`}>
              <div 
                className={`p-6 text-sm font-light leading-relaxed border ${
                  msg.sender === 'guide' 
                    ? 'bg-slate-900 text-white border-slate-900' 
                    : 'bg-slate-50 text-slate-700 border-slate-100'
                }`}
              >
                {msg.text}
              </div>
              {msg.isTranslated && msg.originalText && (
                <div className="text-[9px] text-slate-400 mt-2 px-1 uppercase tracking-widest font-light">
                  Input: {msg.originalText}
                </div>
              )}
              <div className={`text-[8px] text-slate-300 mt-2 px-1 tracking-tighter ${msg.sender === 'guide' ? 'text-right' : 'text-left'}`}>
                {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
              </div>
            </div>
          ))}
          {isTranslating && (
             <div className="self-start text-[9px] text-primary uppercase tracking-[0.2em] animate-pulse font-medium">AI Processing...</div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex gap-4">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Relay message to parent..."
            className="flex-1 bg-white border border-slate-200 px-6 py-4 font-light outline-none focus:border-primary transition-colors text-slate-700 text-sm"
          />
          <button 
            onClick={handleSend}
            className="bg-slate-900 text-white px-10 py-4 uppercase text-[10px] tracking-[0.3em] font-medium hover:bg-primary transition-all whitespace-nowrap shadow-lg shadow-slate-100"
          >
            Relay
          </button>
        </div>
      </div>
      
      <div className="mt-8 text-center">
         <p className="text-[10px] text-slate-200 uppercase tracking-[0.5em] font-light">www.iamaura.app</p>
      </div>
    </div>
  );
};

export default Communication;