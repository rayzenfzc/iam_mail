import React from 'react';
import { ViewState } from '../types';

interface IntelligenceProps {
  onNavigate: (view: ViewState) => void;
}

const Intelligence: React.FC<IntelligenceProps> = ({ onNavigate }) => {
  return (
    <div className="p-6 pb-24 md:p-16 h-full overflow-y-auto">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-12 md:gap-24 mb-16 md:mb-24">
        <div className="col-span-1 md:col-span-2">
          <div className="mb-2 flex items-center gap-3">
             <div className="h-px w-8 bg-primary/50"></div>
             <span className="text-[10px] uppercase tracking-[0.4em] text-primary/80 font-medium italic">Active Synthesis</span>
          </div>
          <h1 className="thin-title text-6xl md:text-8xl uppercase leading-[0.85] text-slate-900">
            <span className="opacity-50">i AM</span><br/>
            <span className="font-light">MAIL</span>
          </h1>
          <div className="mt-12">
            <p className="text-slate-600 font-light text-sm leading-relaxed max-w-xs">
              Your communications have been synthesized. 3 urgent nodes require validation.
            </p>
          </div>
        </div>

        <div className="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="p-10 border border-slate-200 bg-white aura-glow transition-all flex flex-col justify-between shadow-sm">
              <div>
                <span className="text-[9px] uppercase tracking-[0.3em] text-primary font-bold mb-6 block">Focus</span>
                <h3 className="text-2xl font-light text-slate-900 mb-2">Inbox Zero</h3>
                <p className="text-xs text-slate-600 font-light">12 messages neutralized today.</p>
              </div>
              <button onClick={() => onNavigate(ViewState.INBOX)} className="text-[10px] uppercase tracking-[0.2em] font-bold text-primary mt-8 hover:tracking-[0.3em] transition-all">Review Nodes →</button>
           </div>
           <div className="p-10 bg-slate-900 text-white flex flex-col justify-between group cursor-pointer hover:bg-slate-800 transition-all shadow-lg" onClick={() => onNavigate(ViewState.COMPOSE)}>
              <div>
                <span className="text-[9px] uppercase tracking-[0.3em] text-white/60 font-medium mb-6 block">Action</span>
                <h3 className="text-2xl font-light mb-2">Draft Mode</h3>
                <p className="text-xs text-white/40 font-light">Ready for deep focus drafting.</p>
              </div>
              <div className="text-[20px] group-hover:translate-x-2 transition-transform">→</div>
           </div>
        </div>
      </div>

      <div className="border-t border-slate-200 pt-16">
        <h3 className="text-[10px] uppercase tracking-[0.5em] text-slate-500 font-bold mb-12">Synthesis Brief</h3>
        <div className="space-y-4">
           {[
             { title: 'Project Alpha', desc: 'Arjun completed the node integration. 40% performance gain noted.' },
             { title: 'Quarterly Review', desc: 'Elena Rossi sent architecture specs for 2026 expansion.' },
             { title: 'Scheduled Maintenance', desc: 'System node upgrade scheduled for Saturday 02:00 UTC.' }
           ].map((item, i) => (
             <div key={i} className="py-8 px-4 border-b border-slate-100 flex items-start gap-12 hover:bg-slate-50 transition-all group">
                <div className="text-[9px] uppercase tracking-[0.3em] text-slate-400 group-hover:text-primary transition-colors font-bold">0{i+1}</div>
                <div>
                  <h4 className="text-sm font-medium text-slate-900 mb-1">{item.title}</h4>
                  <p className="text-xs text-slate-600 font-light leading-relaxed">{item.desc}</p>
                </div>
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};

export default Intelligence;