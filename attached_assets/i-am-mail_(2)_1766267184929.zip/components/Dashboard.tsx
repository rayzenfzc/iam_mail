import React from 'react';
import { StudentProfile, ViewState } from '../types';

interface DashboardProps {
  onNavigate: (view: ViewState) => void;
  students: StudentProfile[];
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, students }) => {
  return (
    <div className="p-6 pb-24 md:p-16 md:pb-16 h-full overflow-y-auto">
      {/* Hero Branding Section */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-12 mb-16 md:mb-24">
        <div className="col-span-1 md:col-span-2">
          <div className="mb-2 flex items-center gap-3">
             <div className="h-px w-8 bg-primary/30"></div>
             <span className="text-[10px] uppercase tracking-[0.4em] text-primary/60 font-light">Ecosystem</span>
          </div>
          <h1 className="thin-title text-6xl md:text-8xl uppercase leading-[0.85] text-slate-900 mb-8">
            <span className="opacity-40">i AM</span><br/>
            <span className="font-light">AURA</span>
          </h1>
          <div className="mt-12 flex gap-12">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 mb-1 font-light">Status</p>
              <p className="text-sm font-light text-slate-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
                Operational
              </p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 mb-1 font-light">Active Node</p>
              <p className="text-sm font-light text-slate-600 tracking-tight">www.iamaura.app</p>
            </div>
          </div>
        </div>

        <div 
          onClick={() => onNavigate(ViewState.CHILD_ZONE)}
          className="col-span-1 md:col-span-3 flex flex-col justify-end group cursor-pointer"
        >
          <div className="bg-white border border-slate-100 aspect-[21/9] relative flex items-center justify-center aura-glow overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <span className="text-6xl group-hover:scale-110 group-hover:rotate-6 transition-transform duration-700 ease-out">🪁</span>
            <div className="absolute bottom-6 left-6 text-slate-900">
               <div className="text-[10px] uppercase tracking-widest opacity-40 font-light mb-1">Quick Launch</div>
               <div className="text-xl font-light">Enter Child Zone</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-12 border-t border-slate-50 pt-12">
         <div className="col-span-1 md:col-span-3">
            <div className="flex justify-between items-baseline mb-10">
               <h3 className="text-xs uppercase tracking-[0.2em] text-slate-400 font-light">Student Directory</h3>
               <button className="text-primary text-[10px] uppercase tracking-[0.2em] font-medium hover:tracking-[0.3em] transition-all">+ Add Intake</button>
            </div>
            
            <div className="space-y-1">
              {students.map((student) => (
                <div key={student.id} className="flex items-center justify-between py-6 px-4 hover:bg-slate-50 transition-colors border-b border-slate-50 group">
                   <div className="flex items-center gap-6">
                      <div className="w-12 h-12 bg-white border border-slate-100 flex items-center justify-center text-slate-300 font-thin text-xl group-hover:border-primary/20 transition-colors">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-base font-light text-slate-800">{student.name}</div>
                        <div className="text-[9px] text-slate-400 uppercase tracking-widest mt-0.5">{student.diagnosis}</div>
                      </div>
                   </div>
                   <div className="flex items-center gap-12">
                      <div className="text-right hidden sm:block">
                         <div className="text-xs font-light text-slate-500">{student.ratePerHour} AED/hr</div>
                         <div className="text-[8px] text-primary uppercase tracking-widest font-medium mt-1">Authorized</div>
                      </div>
                      <button className="text-slate-200 group-hover:text-primary transition-all group-hover:translate-x-1">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="square" strokeWidth={1} d="M13 5l7 7-7 7M5 12h15"/></svg>
                      </button>
                   </div>
                </div>
              ))}
            </div>
         </div>

         <div className="col-span-1 md:col-span-2 space-y-12">
            <div className="bg-slate-900 p-10 text-white group cursor-pointer hover:bg-slate-800 transition-all duration-500 relative overflow-hidden" onClick={() => onNavigate(ViewState.CONNECT)}>
               <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 -mr-12 -mt-12 rotate-45 group-hover:rotate-90 transition-transform duration-1000"></div>
               <div className="flex justify-between mb-12">
                  <span className="text-3xl grayscale group-hover:grayscale-0 transition-all">🤝</span>
                  <span className="text-[9px] uppercase tracking-[0.3em] border border-white/20 px-3 py-1.5 h-fit font-light">Talk to AURA</span>
               </div>
               <div>
                  <h3 className="text-3xl thin-title mb-2">Skill Guidance</h3>
                  <p className="text-slate-400 font-light text-xs tracking-wide">Connect for parental guidance & skill support</p>
               </div>
            </div>

            <div className="border border-slate-100 p-10 flex flex-col justify-center aura-glow transition-all" onClick={() => onNavigate(ViewState.ADMIN)}>
                <div className="text-[9px] uppercase tracking-[0.3em] text-slate-400 mb-6 font-light">Management</div>
                <h3 className="text-slate-900 font-light text-xl mb-3">System & Billing</h3>
                <p className="text-slate-500 text-xs font-light leading-relaxed">Auto-compile service records and practice billing reports.</p>
                <button className="mt-8 text-primary text-[9px] uppercase tracking-[0.2em] font-medium text-left">Open Admin Console →</button>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Dashboard;